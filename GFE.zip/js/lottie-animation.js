var coworking_a = lottie.loadAnimation({
  container: document.getElementById('testimonial-lottie'), // the dom element that will contain the animation
  renderer: 'svg',
  loop: true,
  autoplay: true,
  path: 'animation/testimonial.json' // the path to the animation json
});
var coworking_a = lottie.loadAnimation({
	container: document.getElementById('choose-lottie'), // the dom element that will contain the animation
	renderer: 'svg',
	loop: true,
	autoplay: true,
	path: 'animation/choose.json' // the path to the animation json
  });
  var coworking_a = lottie.loadAnimation({
	container: document.getElementById('banner-lottie'), // the dom element that will contain the animation
	renderer: 'svg',
	loop: true,
	autoplay: true,
	path: 'animation/banner.json' // the path to the animation json
  });